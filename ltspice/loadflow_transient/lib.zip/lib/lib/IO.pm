#

package IO;

use XSLoader ();
use Carp;

$VERSION = "1.20";
XSLoader::load 'IO', $VERSION;

sub import {
    shift;
    my @l = @_ ? @_ : qw(Handle Seekable File Pipe Socket Dir);

    eval join("", map { "require IO::" . (/(\w+)/)[0] . ";\n" } @l)
	or croak $@;
}

1;

__END__

