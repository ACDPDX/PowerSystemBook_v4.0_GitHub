Version 4
SymbolType BLOCK
LINE Normal -16 0 -32 0
LINE Normal -16 16 -32 16
LINE Normal -28 4 -36 -4
LINE Normal -36 4 -28 -4
LINE Normal -16 32 -16 48
LINE Normal 16 32 16 48
LINE Normal 32 32 32 48
LINE Normal -16 38 -12 32
LINE Normal 16 38 12 32
LINE Normal 20 32 16 38
LINE Normal 28 32 32 38
LINE Normal -6 22 -1 22
LINE Normal -3 17 -6 22
RECTANGLE Normal 32 32 -16 -16
RECTANGLE Normal 27 25 -9 -9
CIRCLE Normal 22 21 -4 -5
TEXT 2 7 Left 4 Vt
WINDOW 0 -8 -24 Left 2
SYMATTR Prefix X
SYMATTR SpiceModel vri_slack2_te_ctrl_LF
SYMATTR ModelFile ltspice_ctrl.lib
SYMATTR Value2 vfactor={vfactor} sfactor={sfactor}
SYMATTR Description voltage slack with control inputs (vmag, delta, tevenin equivalent - on parameter works) - delta is in degree
SYMATTR Value gin=1e12
PIN -32 0 NONE 8
PINATTR PinName v1r
PINATTR SpiceOrder 1
PIN -32 16 NONE 8
PINATTR PinName v1i
PINATTR SpiceOrder 2
PIN 32 -16 NONE 8
PINATTR PinName v1_m
PINATTR SpiceOrder 3
PIN 32 0 NONE 8
PINATTR PinName p1_m
PINATTR SpiceOrder 4
PIN 32 16 NONE 8
PINATTR PinName q1_m
PINATTR SpiceOrder 5
PIN -16 48 RIGHT 8
PINATTR PinName on
PINATTR SpiceOrder 6
PIN 16 48 RIGHT 5
PINATTR PinName vmag
PINATTR SpiceOrder 7
PIN 32 48 LEFT 5
PINATTR PinName delta
PINATTR SpiceOrder 8
