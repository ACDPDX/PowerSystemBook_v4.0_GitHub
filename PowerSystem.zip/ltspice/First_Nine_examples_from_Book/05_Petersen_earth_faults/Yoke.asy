Version 4
SymbolType BLOCK
LINE Normal 0 -80 0 -96
LINE Normal 0 48 0 64
RECTANGLE Normal 15 48 -15 -80
PIN 0 -96 NONE 8
PINATTR PinName m1
PINATTR SpiceOrder 1
PIN 0 64 NONE 8
PINATTR PinName m2
PINATTR SpiceOrder 2
