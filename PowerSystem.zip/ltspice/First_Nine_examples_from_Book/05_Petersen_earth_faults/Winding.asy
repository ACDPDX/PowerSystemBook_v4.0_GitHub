Version 4
SymbolType BLOCK
LINE Normal -32 -16 32 -32
LINE Normal 32 0 -32 -16
LINE Normal -33 16 32 0
LINE Normal 32 32 -33 16
LINE Normal 0 -80 0 -96
LINE Normal 32 32 48 32
LINE Normal 0 48 0 64
LINE Normal -32 -48 32 -32
LINE Normal 32 -64 -32 -48
LINE Normal 48 -64 32 -64
RECTANGLE Normal 16 48 -16 -80
CIRCLE Normal 29 -74 24 -79
PIN 0 64 NONE 8
PINATTR PinName ma
PINATTR SpiceOrder 1
PIN 0 -96 NONE 8
PINATTR PinName mb
PINATTR SpiceOrder 2
PIN 48 -64 NONE 8
PINATTR PinName ea
PINATTR SpiceOrder 3
PIN 48 32 NONE 8
PINATTR PinName eb
PINATTR SpiceOrder 4
