Version 4
SymbolType BLOCK
LINE Normal 0 16 -16 16
LINE Normal 0 32 -16 32
LINE Normal -16 0 0 0
CIRCLE Normal -6 2 -10 -2
CIRCLE Normal -6 18 -10 14
CIRCLE Normal -6 34 -10 30
TEXT -10 7 Left 2 A
SYMATTR Prefix X
SYMATTR SpiceModel ameter_3ph_RMS_50
SYMATTR Description 3 phase amperemeter
SYMATTR ModelFile measure.lib
PIN -16 0 NONE 8
PINATTR PinName IN1
PINATTR SpiceOrder 1
PIN -16 16 NONE 8
PINATTR PinName IN2
PINATTR SpiceOrder 2
PIN -16 32 NONE 8
PINATTR PinName IN3
PINATTR SpiceOrder 3
PIN 0 0 NONE 8
PINATTR PinName OUT1
PINATTR SpiceOrder 4
PIN 0 16 NONE 8
PINATTR PinName OUT2
PINATTR SpiceOrder 5
PIN 0 32 NONE 8
PINATTR PinName OUT3
PINATTR SpiceOrder 6
PIN 0 -16 NONE 8
PINATTR PinName M_E
PINATTR SpiceOrder 7
